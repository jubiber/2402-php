import { createStore } from 'vuex';

const store = createStore({
    state() {
        return {
            AuthFlg: false,
        }
    },
    mutations: {

    },
    actions: {

    }
});

export default store;
